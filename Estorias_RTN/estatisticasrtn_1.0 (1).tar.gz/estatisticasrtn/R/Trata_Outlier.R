Trata_Outlier <-
function(series){
  library(strucchange)
  library(forecast)
  
  for (s in(1:NCOL(series))){
    serie_trabalho<- series[,s]
    #Verifica os pontos que são outliers
    
    #Verifica se os pontos que são outliers são também outliers em uma estrutura específica. Se fizerem serão descartados
    serie_cus <- efp(serie_trabalho ~ 1, type = "Rec-CUSUM")
    bound <- boundary(serie_cus, alpha = 0.01)
    
    true_outlier <- c(numeric())
    #Trata estruturas acima de uma linha de fronteira
    pontos<-which(serie_cus$process>=bound)
    if (length(pontos)>0){
      q<- quantile(serie_trabalho[pontos])
      vec_outlier<- pontos[which(serie_trabalho[pontos]>q[4]*1.5)]
      if (length(vec_outlier)>0) {true_outlier<-c(true_outlier,vec_outlier)}
      vec_outlier<- pontos[which(serie_trabalho[pontos]<q[2]*0.5)]
      if (length(vec_outlier)>0) {true_outlier<-c(true_outlier,vec_outlier)}
      
    }
    
    
    #Trata estruturas abaixo de uma linha de fronteira
    pontos<-which(serie_cus$process<=-bound)
    if (length(pontos)>0){
      q<- quantile(serie_trabalho[pontos])
      vec_outlier<- pontos[which(serie_trabalho[pontos]>q[4]*1.5)]
      if (length(vec_outlier)>0) {true_outlier<-c(true_outlier,vec_outlier)}
      vec_outlier<- pontos[which(serie_trabalho[pontos]<q[2]*0.5)]
      if (length(vec_outlier)>0) {true_outlier<-c(true_outlier,vec_outlier) }
      
    }
    
    #Trata estruturas entre duas linhas de fronteira
    pontos<-which(serie_cus$process>=-bound&serie_cus$process<=bound)
    if (length(pontos)>0){
      q<- quantile(serie_trabalho[pontos])
      vec_outlier<- pontos[which(serie_trabalho[pontos]>q[4]*1.5)]
      if (length(vec_outlier)>0) {true_outlier<-c(true_outlier,vec_outlier)}
      vec_outlier<- pontos[which(serie_trabalho[pontos]<q[2]*0.5)]
      if (length(vec_outlier)>0) {true_outlier<-c(true_outlier,vec_outlier)}
      
    }
    
    if (length(true_outlier)>0){
      true_outlier<-true_outlier [order(true_outlier)]
      
      
      for (i in (1:length(true_outlier))){
        if (length(serie_trabalho[1:true_outlier[i]-1])>0){
          fit<-auto.arima(serie_trabalho[1:true_outlier[i]-1])
          serie_trabalho[true_outlier[i]] <- forecast(fit,h=1)$mean
          
        }
        
      }
      
      
    }
    
    if (s==1) {
      series_ajustadas<-serie_trabalho}
    else {
      series_ajustadas<-cbind(series_ajustadas,serie_trabalho)}
    #print(s)
    
  }
  
  colnames(series_ajustadas)<-colnames(series)
  series_ajustadas
}
