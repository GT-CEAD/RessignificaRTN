GraficoSeries <-
function(series,rubricas,rotulos, nome_grafico, altura=260, options){
  library(magrittr)
  library(dygraphs) #Série temporal dinâmica
  library(lubridate)
  
  y_min <- min(as.numeric(series))
  y_max <- max(as.numeric(series))
 
 
  series[series==0]<-NA
  
  cssFile <- ""
  if(options$show != "follow"){
    cssFile <- "grafico.css"
  }else{
  }
  
  titulo_Grafico <- NULL
  if(options$title_position_down){
    tituloMain = NULL
    tituloXlab = nome_grafico
  }else{
    tituloMain = nome_grafico
    tituloXlab = NULL
  }
  
  dygraph(series, width="90%", height = altura, main = tituloMain, xlab = tituloXlab) %>%
    dyLegend( hideOnMouseOut = FALSE, show = options$show)%>%
    dyOptions(connectSeparatedPoints = TRUE, titleHeight = 25, labelsUTC = TRUE)%>%
    dyOptions( drawGrid = FALSE, 
               drawXAxis = options$axis, 
               drawYAxis = options$axis, 
               colors = options$cor_linha) %>%
    dyHighlight(highlightCircleSize = 5, hideOnMouseOut = FALSE) %>%
    dyCSS("style.css") %>%
    dyCSS(cssFile) %>%
    dyAxis(name='x', valueFormatter = mes_abreviado) %>%
    dyAxis(name= 'y', valueRange = c(y_min,y_max*1.35),
           valueFormatter = casa_do_milhar, axisLabelFormatter = mes_abreviado)
 
  # 
  # graph<-paste0("dygraph(series,main = nome_grafico) %>%  dyRangeSelector() %>%  dyAxis(name= 'y',valueRange = c(",y_min,",",y_max,")) %>%  dyLegend(show = 'follow', hideOnMouseOut = TRUE, width = 400)%>%  dyOptions(connectSeparatedPoints = TRUE) %>% dyOptions( drawGrid = FALSE) %>% dyHighlight(highlightCircleSize = 5)")
  # eval(parse(text=RotulaSeries(grap,rotulos)))
  
}
